package com.example.WEB_ALUNO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAlunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAlunoApplication.class, args);
	}

}
