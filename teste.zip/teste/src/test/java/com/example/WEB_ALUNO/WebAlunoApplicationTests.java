package com.example.WEB_ALUNO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
